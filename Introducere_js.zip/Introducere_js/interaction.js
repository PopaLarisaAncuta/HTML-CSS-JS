class Student 
{
        constructor(nume, prenume, data_nasterii, foaie_matricola) 
		{
          this.nume = nume;
          this.prenume = prenume;
          this.data_nasterii = data_nasterii;
          this.foaie_matricola = foaie_matricola;
        }
		
		afiseazaVarsta() 
		{
			//data curenta
          var currentDate = new Date();
		    //conversie data nasterii din string intr-un obiect de tip date
		  var birthDate = new Date(this.data_nasterii);
		  
		  var age = currentDate.getFullYear()-birthDate.getFullYear();
		  
		    //verificam daca luna curenta este mai mica decat luna din data nasterii
		  var month=currentDate.getMonth()-birthDate.getMonth();
		  if(month < 0 || (month == 0 && currentDate.getDate() < birthDate.getDate()))
			  age--;
		  
		  return age;
        }
		
		afiseazaNotele()
		{
			return this.foaie_matricola.map(String).join(',');
		}
		
		calculeazaMedia()
		{
			const sum = this.foaie_matricola.reduce((total,value) => total + value,0);
			return sum/this.foaie_matricola.length;
		}
		
		adaugaNota(newValue)
		{
			this.foaie_matricola.push(newValue);
		}
		
		setNume(nume)
		{
			this.nume=nume;
		}
		
		setPrenume(prenume)
		{
			this.prenume=prenume;
		}
		
		setDataNasterii(data_nasterii)
		{
			this.data_nasterii=data_nasterii;
		}
}

textAfisat = ""; //variabila de tip text, folosita la output

function f1()
{
	displayer = document.getElementById("displayer");
	
	grupa = [];
	grupa.push(new Student("N2","P1","2001/06/24",[9,10,9]));
	grupa.push(new Student("N1","P2","2002/08/15",[8,10,7]));
	grupa.push(new Student("N1","P1","2001/12/15",[7,9]));
	
	//afisare lista studenti
	textAfisat += "Lista studentilor: ";
	for(i in grupa)
	{
		textAfisat += "<br>";
		attr = Object.keys(grupa[i]);
		for(j in attr)
		{
			textAfisat += attr[j] + ": ";
			if(typeof(grupa[i][attr[j]]) != "function")
				textAfisat += grupa[i][attr[j]] + ", ";
			else
				textAfisat += grupa[i][attr[j]]();	
		}
	}
	 
	 //ordonare alfabetica dupa nume si prenume
	 textAfisat += "<br><br>Ordonare alfabetica dupa nume si prenume: ";
	 sortareAlfabetica(grupa,"nume","prenume");
	 for(i=0; i<grupa.length; i++)
		textAfisat += "<br>"+grupa[i].nume + " " + grupa[i].prenume;
	
	 //ordonare dupa medii
	 textAfisat += "<br><br>Ordonare dupa medie: ";
	 sortareMedie(grupa,"foaie_matricola");
	 for(i=0; i<grupa.length; i++)
		textAfisat += "<br>"+grupa[i].nume + " " + grupa[i].prenume + " " + grupa[i].calculeazaMedia();
	
	//ordonare dupa varsta
	textAfisat += "<br><br>Ordonare dupa varsta: ";
	 grupa.sort(sortareVarsta);
	 for(i=0; i<grupa.length; i++)
		textAfisat += "<br>"+grupa[i].nume + " " + grupa[i].prenume + " " + grupa[i].afiseazaVarsta();
	
	//adauga note noi si reordoneaza dupa medii
	grupa[0].adaugaNota(3);
	grupa[1].adaugaNota(5);
	grupa[2].adaugaNota(10);
	textAfisat += "<br><br>Ordonare dupa medie dupa adaugarea de note noi: ";
	
	 sortareMedie(grupa,"foaie_matricola");
	 for(i=0; i<grupa.length; i++)
		textAfisat += "<br>"+grupa[i].nume + " " + grupa[i].prenume + " " + grupa[i].calculeazaMedia();
	
	//schimbare nume studenti
	textAfisat += "<br><br>Ordonare alfabetica cu schimbari de nume:";
	grupa[0].nume = "Nume";
	grupa[2].nume = "N5";
	grupa[1].setNume("N");
	sortareAlfabetica(grupa,"nume","prenume");
	 for(i=0; i<grupa.length; i++)
		textAfisat += "<br>"+grupa[i].nume + " " + grupa[i].prenume;
	
	//exceptii
	for(i=0;i<grupa.length;i++)
	{
		try
		{
			if (grupa[i].nume.length < 2) {
              throw "Sirul de caractere trebuie sa aiba o lungime mai mare decat 2.";
                     }
              if (/\d/.test(grupa[i].nume)) {
              throw "Sirul de caractere nu poate contine caractere numerice.";
              }
		}
		catch(error){
			console.log(error);
		}
	}
	
	grupa[0].setDataNasterii("2012/06/24");
	for(i=0;i<grupa.length;i++)
	{
		try
		{
           if (grupa[i].afiseazaVarsta() < 18)
			   throw "Studentul are sub 18 ani.";
		}
		catch(error){
			console.log(error);
		}
	}

	displayer.innerHTML = textAfisat;
}

function sortareAlfabetica(arr, attr1, attr2) 
{
  arr.sort((a, b) => {
    if (a[attr1] < b[attr1])
		return -1;
    if (a[attr1] > b[attr1]) 
		return 1;

    if (a[attr2] < b[attr2]) 
		return -1;
    if (a[attr2] > b[attr2]) 
		return 1;

    return 0;
  });
}

function sortareMedie(arr, attr) 
{
  // copiem metoda calculeazaMedia() a obiectelor din array intr-o variabila locala
  const calculeazaMedia = arr[0].calculeazaMedia;

  arr.sort((a, b) => {
    const medieA = calculeazaMedia.call(a, attr);
    const medieB = calculeazaMedia.call(b, attr);

    if (medieA < medieB) 
		return -1;
    if (medieA > medieB)
		return 1;
	
    return 0;
  });
}

function sortareVarsta(a, b) 
{
  const varstaA = a.afiseazaVarsta();
  const varstaB = b.afiseazaVarsta();

  if (varstaA < varstaB)
    return -1;
  if (varstaA > varstaB)
    return 1;
 
  return 0;
}
